DEVICE CHECKUP - 보안·네트워크 정밀 점검

사용법
1) 이 폴더의 RUN-CHECK.cmd를 더블클릭합니다.
2) Windows 네트워크 증거를 읽기 전용으로 수집합니다.
3) 수집 결과가 정상일 때만 분석 화면이 자동으로 열립니다.

수집하는 것
- Windows Defender Firewall 프로필 상태
- 현재 TCP 연결
- 연결 PID의 프로세스/서비스 이름
- Neighbor cache의 LAN 기기 후보
- 읽을 수 있는 경우 Windows Firewall 로그 최근 최대 5,000줄

하지 않는 것
- 외부 호스트 스캔
- 방화벽 규칙 변경
- 프로세스 종료
- 서버 업로드

주의
'위험 신호 있음'은 침입 성공 확정이 아니라 추가 확인 우선순위입니다.
