(function(root,factory){
  const api=factory();
  if(typeof module==='object'&&module.exports) module.exports=api;
  root.IntrusionCore=api;
})(typeof globalThis!=='undefined'?globalThis:this,function(){
  const SENSITIVE=new Set([21,22,23,25,53,80,110,135,139,143,389,443,445,1433,1521,3306,3389,5432,5900,6379,8080,8443,9200,27017]);
  const COMMON_CLIENT_REMOTE=new Set([53,80,123,443,465,587,993,995,5228]);
  const EPHEMERAL_MIN=49152;

  function isPrivateIp(ip){
    if(!ip||ip==='-'||ip==='::1'||ip==='0.0.0.0') return true;
    const clean=String(ip).replace(/^\[|\]$/g,'');
    if(clean.includes(':')) return /^(fe80:|fc|fd|::1$)/i.test(clean);
    const p=clean.split('.').map(Number);
    if(p.length!==4||p.some(Number.isNaN)) return false;
    return p[0]===10||p[0]===127||(p[0]===169&&p[1]===254)||(p[0]===192&&p[1]===168)||(p[0]===172&&p[1]>=16&&p[1]<=31);
  }
  function parseFirewall(text){
    const lines=String(text||'').replace(/^\uFEFF/,'').split(/\r?\n/); let fields=null; const out=[];
    for(const raw of lines){
      const line=raw.trim(); if(!line) continue;
      if(line.startsWith('#Fields:')){fields=line.slice(8).trim().split(/\s+/); continue;}
      if(line.startsWith('#')) continue;
      if(!fields) continue;
      const parts=line.split(/\s+/); if(parts.length<fields.length) continue;
      const r={}; fields.forEach((f,i)=>r[f]=parts[i]); out.push(r);
    }
    return out;
  }
  function normaliseFirewall(r){
    const direction=String(r.path||'').toUpperCase()==='RECEIVE'?'inbound':String(r.path||'').toUpperCase()==='SEND'?'outbound':'unknown';
    return {
      source:'firewall', when:[r.date||'',r.time||''].filter(Boolean).join(' '),
      action:String(r.action||'').toUpperCase(), protocol:String(r.protocol||'').toUpperCase(),
      src:r['src-ip']||r.src||'', dst:r['dst-ip']||r.dst||'',
      sport:Number(r['src-port']||0), dport:Number(r['dst-port']||0),
      path:String(r.path||r.info||'').toUpperCase(), process:r.pid&&r.pid!=='-'?String(r.pid):'',
      processName:'', services:[], direction
    };
  }
  function inferTcpDirection(x){
    const lp=Number(x.LocalPort||x.localPort||0), rp=Number(x.RemotePort||x.remotePort||0);
    if(lp>=EPHEMERAL_MIN && COMMON_CLIENT_REMOTE.has(rp)) return 'likely_outbound';
    if(SENSITIVE.has(lp) && rp>=1024) return 'possible_inbound';
    if(lp>=EPHEMERAL_MIN && rp>0) return 'likely_outbound';
    return 'unknown';
  }
  function normalizeCollector(obj){
    const pmap=obj.processNames||{}; const smap=obj.servicesByPid||{}; const out=[];
    for(const x of (obj.tcpConnections||[])){
      const pid=String(x.OwningProcess??x.owningProcess??'');
      out.push({
        source:'tcp',when:obj.collectedAt||'',action:String(x.State||x.state||''),protocol:'TCP',
        src:String(x.RemoteAddress||x.remoteAddress||''),dst:String(x.LocalAddress||x.localAddress||''),
        sport:Number(x.RemotePort||x.remotePort||0),dport:Number(x.LocalPort||x.localPort||0),
        path:'CURRENT',process:pid,processName:String(pmap[pid]||''),services:Array.isArray(smap[pid])?smap[pid]:[],
        direction:inferTcpDirection(x)
      });
    }
    return out;
  }
  function parseWhen(s){const t=Date.parse(String(s||'').replace(' ','T'));return Number.isFinite(t)?t:0;}
  function groupEvents(events){
    const external=events.filter(e=>e.src&&!isPrivateIp(e.src)); const map=new Map();
    for(const e of external){
      if(!map.has(e.src)) map.set(e.src,{ip:e.src,count:0,drops:0,allows:0,inboundDrops:0,inboundAllows:0,established:0,possibleInboundEstablished:0,likelyOutboundEstablished:0,ports:new Set(),last:'',sources:new Set(),processes:new Set(),services:new Set(),times:[]});
      const x=map.get(e.src); x.count++; x.sources.add(e.source); if(e.dport)x.ports.add(e.dport); if(e.when>x.last)x.last=e.when; const ts=parseWhen(e.when); if(ts)x.times.push(ts);
      if(e.action==='DROP'){x.drops++; if(e.direction==='inbound')x.inboundDrops++;}
      if(e.action==='ALLOW'){x.allows++; if(e.direction==='inbound')x.inboundAllows++;}
      if(e.source==='tcp'&&String(e.action).toUpperCase()==='ESTABLISHED'){
        x.established++; if(e.direction==='possible_inbound')x.possibleInboundEstablished++; if(e.direction==='likely_outbound')x.likelyOutboundEstablished++;
      }
      if(e.processName)x.processes.add(e.processName); for(const s of (e.services||[]))x.services.add(s);
    }
    return [...map.values()].map(x=>{
      const arr=[...x.times].sort((a,b)=>a-b); let burst=0,left=0;
      for(let right=0;right<arr.length;right++){while(arr[right]-arr[left]>60000)left++;burst=Math.max(burst,right-left+1);}
      return {...x,ports:[...x.ports].sort((a,b)=>a-b),sources:[...x.sources],processes:[...x.processes],services:[...x.services],burst60s:burst};
    }).sort((a,b)=>b.count-a.count);
  }
  function riskFor(x){
    let score=0; const reasons=[], counter=[];
    const sensitive=x.ports.filter(p=>SENSITIVE.has(Number(p)));
    if(x.inboundDrops>=5){score+=2;reasons.push(`외부→내부 차단 ${x.inboundDrops}회`);}
    if(x.inboundDrops>=20){score+=2;reasons.push('외부→내부 반복 차단');}
    if(x.ports.length>=6 && x.inboundDrops>=6){score+=3;reasons.push(`여러 포트 탐색 ${x.ports.length}개`);}
    if(x.burst60s>=10 && x.inboundDrops>=5){score+=2;reasons.push(`1분 내 최대 ${x.burst60s}회 집중 접근`);}
    if(sensitive.length && x.inboundDrops>0){score+=2;reasons.push(`민감 포트 차단 ${sensitive.slice(0,6).join(',')}`);}
    if(x.possibleInboundEstablished>0){score+=3;reasons.push(`현재 인바운드 가능 ESTABLISHED ${x.possibleInboundEstablished}건`);}
    if(x.inboundAllows>0){score+=1;reasons.push(`외부→내부 허용 ${x.inboundAllows}회`);}
    if(x.likelyOutboundEstablished>0){counter.push(`일반 아웃바운드 추정 ${x.likelyOutboundEstablished}건`); score=Math.max(0,score-1);}
    if(x.processes.length) counter.push(`프로세스 ${x.processes.slice(0,4).join(', ')}`);
    if(score>=7)return{label:'위험 신호 있음',cls:'high',score,reasons,counter};
    if(score>=3)return{label:'확인 필요',cls:'medium',score,reasons,counter};
    return{label:'정상 가능성 높음',cls:'low',score,reasons:reasons.length?reasons:['강한 침입 패턴 부족'],counter};
  }
  function analyseFirewallText(text){const raw=parseFirewall(text);const events=raw.map(normaliseFirewall);return{raw,events,groups:groupEvents(events)};}
  function analyseCollectorJson(text){const obj=typeof text==='string'?JSON.parse(text):text;const events=normalizeCollector(obj);return{object:obj,events,groups:groupEvents(events)};}
  function mergeEvidence(firewallText,collectorObj){
    const fw=firewallText?analyseFirewallText(firewallText).events:[];
    const tcp=collectorObj?analyseCollectorJson(collectorObj).events:[];
    return {events:[...fw,...tcp],groups:groupEvents([...fw,...tcp]),collector:collectorObj||null};
  }
  return{SENSITIVE,COMMON_CLIENT_REMOTE,isPrivateIp,parseFirewall,normaliseFirewall,inferTcpDirection,normalizeCollector,groupEvents,riskFor,analyseFirewallText,analyseCollectorJson,mergeEvidence};
});
