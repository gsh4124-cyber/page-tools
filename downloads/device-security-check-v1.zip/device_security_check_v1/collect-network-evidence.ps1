# DEVICE CHECKUP Security v1 - defensive local evidence collector
# Read-only: no remote scanning, no firewall rule changes, no process termination.
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$jsonOut = Join-Path $here 'network-evidence.json'
$bundleOut = Join-Path $here 'evidence.bundle.js'

$errors = @()
$warnings = @()

function Try-Collect([scriptblock]$Block, [string]$Label) {
  try { return @(& $Block) }
  catch {
    $script:errors += "$Label: $($_.Exception.Message)"
    return @()
  }
}

$profiles = Try-Collect { Get-NetFirewallProfile | Select-Object Name,Enabled,DefaultInboundAction,DefaultOutboundAction,LogAllowed,LogBlocked,LogFileName } 'Firewall profiles'
$tcp = Try-Collect { Get-NetTCPConnection | Select-Object LocalAddress,LocalPort,RemoteAddress,RemotePort,State,OwningProcess } 'TCP connections'
$neighbors = Try-Collect { Get-NetNeighbor | Where-Object { $_.State -ne 'Unreachable' } | Select-Object ifIndex,IPAddress,LinkLayerAddress,State,AddressFamily } 'Neighbor cache'

$processMap = [ordered]@{}
try {
  Get-Process | ForEach-Object {
    if ($null -ne $_.Id) { $processMap[[string]$_.Id] = $_.ProcessName }
  }
} catch { $errors += "Processes: $($_.Exception.Message)" }

$servicesByPid = [ordered]@{}
try {
  Get-CimInstance Win32_Service | ForEach-Object {
    $servicePid = [string]$_.ProcessId
    if ($servicePid -and $servicePid -ne '0') {
      if (-not $servicesByPid.Contains($servicePid)) { $servicesByPid[$servicePid] = @() }
      $servicesByPid[$servicePid] = @($servicesByPid[$servicePid]) + [string]$_.Name
    }
  }
} catch { $errors += "Services: $($_.Exception.Message)" }

# Best-effort firewall log discovery. We only embed a recent tail, never modify logging.
$firewallLogText = ''
$logCandidates = @()
foreach ($p in $profiles) {
  if ($p.LogFileName) {
    $expanded = [Environment]::ExpandEnvironmentVariables([string]$p.LogFileName)
    if ($expanded -and ($logCandidates -notcontains $expanded)) { $logCandidates += $expanded }
  }
}
if ($logCandidates.Count -eq 0) {
  $logCandidates += (Join-Path $env:SystemRoot 'System32\LogFiles\Firewall\pfirewall.log')
}
foreach ($candidate in $logCandidates) {
  try {
    if (Test-Path -LiteralPath $candidate) {
      $tail = Get-Content -LiteralPath $candidate -Tail 5000 -ErrorAction Stop
      $firewallLogText = ($tail -join "`n")
      break
    }
  } catch {
    $warnings += "Firewall log unreadable: $candidate"
  }
}
if (-not $firewallLogText) { $warnings += 'No readable Windows Firewall log was found. Current connections can still be analyzed.' }

$payload = [ordered]@{
  schema = 'device-checkup/security-evidence-v1'
  collectedAt = (Get-Date).ToString('o')
  computerName = $env:COMPUTERNAME
  collector = [ordered]@{
    version = '1.0'
    errors = $errors
    warnings = $warnings
    firewallLogEmbedded = [bool]$firewallLogText
  }
  firewallProfiles = @($profiles)
  tcpConnections = @($tcp)
  neighbors = @($neighbors)
  processNames = $processMap
  servicesByPid = $servicesByPid
}

$json = $payload | ConvertTo-Json -Depth 8 -Compress
if ([string]::IsNullOrWhiteSpace($json) -or $json.Length -lt 20) { throw 'Collector produced empty JSON.' }
# Parse-back validation before writing success artifacts.
$null = $json | ConvertFrom-Json -ErrorAction Stop

# UTF-8 without BOM for browser/tool compatibility.
[IO.File]::WriteAllText($jsonOut, $json, [Text.UTF8Encoding]::new($false))
$fwJson = $firewallLogText | ConvertTo-Json -Compress
$bundle = "window.__NETWORK_EVIDENCE__ = $json;`nwindow.__FIREWALL_LOG_TEXT__ = $fwJson;`n"
[IO.File]::WriteAllText($bundleOut, $bundle, [Text.UTF8Encoding]::new($false))

# Final on-disk validation. Do not claim success if files are effectively empty.
$j = Get-Item -LiteralPath $jsonOut -ErrorAction Stop
$b = Get-Item -LiteralPath $bundleOut -ErrorAction Stop
if ($j.Length -lt 20 -or $b.Length -lt 50) { throw 'Evidence files were created but are unexpectedly empty.' }

Write-Host "Evidence OK: $jsonOut ($($j.Length) bytes)"
Write-Host "Bundle OK:   $bundleOut ($($b.Length) bytes)"
exit 0
