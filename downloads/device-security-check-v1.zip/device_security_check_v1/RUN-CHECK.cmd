@echo off
setlocal
cd /d "%~dp0"
title DEVICE CHECKUP Security

echo [1/3] Collecting read-only Windows network evidence...
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0collect-network-evidence.ps1"
if errorlevel 1 (
  echo.
  echo [FAIL] Evidence collection failed. The result page will NOT be opened.
  echo Please capture this window and send it for diagnosis.
  pause
  exit /b 1
)

for %%F in ("%~dp0network-evidence.json") do set SIZE=%%~zF
if not defined SIZE (
  echo [FAIL] network-evidence.json was not created.
  pause
  exit /b 1
)
if %SIZE% LSS 20 (
  echo [FAIL] network-evidence.json is empty or invalid.
  pause
  exit /b 1
)

echo [2/3] Evidence validated: %SIZE% bytes
echo [3/3] Opening the local analysis dashboard...
start "" "%~dp0index.html"
exit /b 0
